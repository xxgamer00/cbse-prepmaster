# CBSE PrepMaster

A comprehensive test preparation platform for CBSE Class 8 & 9 students.

## Features

- Role-based access for admins/teachers and students
- CBSE syllabus-aligned test creation and management
- Integration with Open Trivia DB for question bank
- Real-time test taking interface
- Detailed performance analytics
- Chapter-wise progress tracking

## Tech Stack

- Frontend: React.js
- Backend: Node.js + Express.js
- Database: MongoDB
- Authentication: JWT
- External API: Open Trivia DB

## Project Structure

```
cbse-prepmaster/
├── client/                 # Frontend React application
│   ├── public/
│   └── src/
│       ├── components/     # Reusable UI components
│       ├── pages/         # Main application pages
│       ├── services/      # API integration services
│       ├── context/       # Auth and other context providers
│       └── utils/         # Helper functions
└── server/                # Backend Node.js application
    ├── config/           # Configuration files
    ├── controllers/      # Route controllers
    ├── models/          # MongoDB schemas
    ├── routes/          # API routes
    ├── middleware/      # Custom middleware
    └── utils/           # Helper functions
```

## API Endpoints

### Authentication

- POST `/api/auth/register` - Register new user
- POST `/api/auth/login` - Login user
- GET `/api/auth/profile` - Get user profile
- PUT `/api/auth/profile` - Update user profile

### Tests

- POST `/api/tests` - Create new test (admin only)
- GET `/api/tests` - Get all tests (filtered by role)
- GET `/api/tests/:id` - Get test by ID
- PUT `/api/tests/:id` - Update test (admin only)
- DELETE `/api/tests/:id` - Delete test (admin only)
- POST `/api/tests/add-questions` - Add questions from Open Trivia DB (admin only)

### Questions

- POST `/api/questions` - Create new question (admin only)
- GET `/api/questions` - Get questions with filters
- GET `/api/questions/:id` - Get question by ID
- PUT `/api/questions/:id` - Update question (admin only)
- DELETE `/api/questions/:id` - Delete question (admin only)
- POST `/api/questions/bulk-import` - Bulk import questions (admin only)

### Results

- POST `/api/results/submit` - Submit test
- GET `/api/results/student` - Get student's results
- GET `/api/results/:id` - Get result by ID
- GET `/api/results/analytics` - Get class analytics (admin only)

## Setup Instructions

1. Clone the repository
2. Install dependencies:
   ```bash
   # Install backend dependencies
   cd server
   npm install

   # Install frontend dependencies
   cd ../client
   npm install
   ```

3. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Update MongoDB URI and JWT secret

4. Start the development servers:
   ```bash
   # Start backend server
   cd server
   npm run dev

   # Start frontend development server
   cd ../client
   npm start
   ```

## Environment Variables

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/cbse-prepmaster
JWT_SECRET=your-secret-key
OPENTDB_API_URL=https://opentdb.com/api.php
```

## Contributing

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## License

MIT License
